// Stores the retailer's customer list in Netlify Blobs, one entry per customer.
// Requires the ACCESS_CODE environment variable to be set in Netlify.
import { getStore } from "@netlify/blobs";

const RETAILER = "lindo-home-furniture";
const json = (data, status = 200) =>
  new Response(JSON.stringify(data), { status, headers: { "Content-Type": "application/json", "Cache-Control": "no-store" } });
const clean = (v, max) => String(v ?? "").trim().slice(0, max);

export default async (req) => {
  const expected = process.env.ACCESS_CODE;
  if (!expected) return json({ error: "not_configured" }, 500);
  if ((req.headers.get("x-access-code") || "") !== expected) return json({ error: "bad_code" }, 401);

  const store = getStore({ name: "call-lists", consistency: "strong" });
  const prefix = RETAILER + "/";

  if (req.method === "GET") {
    const { blobs } = await store.list({ prefix });
    const items = await Promise.all(blobs.map((b) => store.get(b.key, { type: "json" })));
    const list = items.filter(Boolean).sort((a, b) => a.createdAt.localeCompare(b.createdAt));
    return json(list);
  }

  if (req.method === "POST") {
    let body;
    try { body = await req.json(); } catch { return json({ error: "bad_request" }, 400); }

    if (body.action === "add") {
      const c = body.customer || {};
      const digits = String(c.phone || "").replace(/\D/g, "").replace(/^1(?=\d{10}$)/, "");
      const entry = {
        id: crypto.randomUUID(),
        name: clean(c.name, 120),
        phone: digits.length === 10 ? `${digits.slice(0, 3)}-${digits.slice(3, 6)}-${digits.slice(6)}` : "",
        date: clean(c.date, 10),
        item: clean(c.item, 300),
        createdAt: new Date().toISOString(),
      };
      if (!entry.name || !entry.phone || !/^\d{4}-\d{2}-\d{2}$/.test(entry.date) || !entry.item)
        return json({ error: "invalid_customer" }, 400);
      await store.setJSON(prefix + entry.id, entry);
      return json(entry, 201);
    }

    if (body.action === "remove" && typeof body.id === "string" && /^[\w-]{1,64}$/.test(body.id)) {
      await store.delete(prefix + body.id);
      return json({ ok: true });
    }

    if (body.action === "clear") {
      const { blobs } = await store.list({ prefix });
      await Promise.all(blobs.map((b) => store.delete(b.key)));
      return json({ ok: true, removed: blobs.length });
    }
    return json({ error: "bad_request" }, 400);
  }
  return json({ error: "method_not_allowed" }, 405);
};

export const config = { path: "/api/customers" };
