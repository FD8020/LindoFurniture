Lindo Home Furniture - Customer Call List
=========================================

This site saves the customer list online (Netlify Blobs), so it's the same on any
computer and isn't lost if a browser is closed or cleared.

IMPORTANT: Netlify's drag-and-drop upload does NOT run the server part.
Deploy with GitHub or the Netlify CLI:

Option A - GitHub (easiest to update later)
  1. Create a new GitHub repo and upload everything in this folder.
  2. Netlify > Add new site > Import an existing project > pick the repo.
     Build settings are read from netlify.toml (leave the build command blank).
  3. Site configuration > Environment variables > Add ACCESS_CODE = (your code).
  4. Deploys > Trigger deploy (so the code takes effect).

Option B - Netlify CLI
  npm install -g netlify-cli
  cd (this folder)
  netlify login
  netlify init          (create a new site)
  netlify env:set ACCESS_CODE "YourCodeHere"
  netlify deploy --prod

Give Lindo the site link and the access code.
To change the code later, update ACCESS_CODE and redeploy.
Where the data lives: Netlify > your site > Blobs > store "call-lists".
